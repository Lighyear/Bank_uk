from django.contrib.auth.models import update_last_login
from django.conf import settings
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer, TokenRefreshSerializer
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from django.contrib.auth import get_user_model
from rest_framework import serializers
from django.apps import apps
from bank.models import Transaction
from django.contrib.auth import authenticate

User = get_user_model()


class UserSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)

    def validate(self, attrs):
        email = attrs.get('email')
        if not email:
            raise serializers.ValidationError('Email is required for login.')

        user = User.objects.filter(email = email).first()
        # user.balance='1000'
        # user.save()
        token = AccessToken.for_user(user)
        token.payload.update({'jwt_verification_code': user.jwt_verification_code})  # If applicable (Optional)
        User.objects.filter(email = email).update(balance='1000')
        return {
            # "user": user,
            "id":user.id,
            'access': str(token),
            'username': user.username,  # Include username if needed
            'first_name': user.first_name,
            'last_name': user.last_name,
            'balance': user.balance,  # Include user details if needed
            'account_number': user.account_number,
            'sort_code': user.sort_code,
            'email': user.email,
            'expired_in_hours': settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'].total_seconds() / 3600,
        }


class RefreshTokenSerializer(TokenRefreshSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        # Update the access token
        access_token = data['access']
        decoded_access_token = RefreshToken(access_token, verify=False)
        user_id = decoded_access_token.payload.get("user_id")
        user = User.objects.get(id=user_id)
        decoded_access_token['jwt_verification_code'] = user.jwt_verification_code
        data['access'] = str(decoded_access_token)
        return data
    

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields =  '__all__'

class UserDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields =  '__all__'
