from django.urls import path
from bank.views import AuthLoginView, TokenVerifyView, AuthTokenRefreshView, TransactionView, UserManager

urlpatterns = [
   
   path('user/update', UserManager.as_view({"post":"update_user"})),
   path('user/login', AuthLoginView.as_view()),
   path('token/verify', TokenVerifyView.as_view({"post":"token_verify"}), name='token_verify'),
   path('token/refresh', AuthTokenRefreshView.as_view()),
   path('transaction/listing', TransactionView.as_view({"post": "listing"})),
   path('transaction/payment', TransactionView.as_view({"post": "transaction"})),
   path('transaction/graph', TransactionView.as_view({"get": "graph_data"})),
   
   
#    TransactionView
]