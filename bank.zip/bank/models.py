from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.
class User(AbstractUser):

    account_number = models.CharField(max_length=50, null=True, blank=True)
    balance = models.IntegerField(null=True, blank=True)
    initial_balance = models.IntegerField(null=True, blank=True)
    jwt_verification_code = models.CharField(max_length=20, blank=True, null=True)
    sort_code = models.CharField(max_length=20, blank=True, null=True, default = "090128")

    def __str__(self):
        return self.username or self.email

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'


class Transaction(models.Model):
    UPI="upi"
    BANK= 'bank'
    PRIORITY_CHOICES = (
        (UPI, 'UPI'),
        (BANK, 'Bank'),
    )

    amount = models.IntegerField()
    user = models.ForeignKey(to=User, on_delete=models.CASCADE, null=True, blank=True, related_name="user")
    is_credit = models.BooleanField(default=False)
    type = models.SlugField(choices=PRIORITY_CHOICES, max_length=100, null=True, blank=True)
    transaction_type = models.CharField(max_length=128, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Transaction'
        verbose_name_plural = 'Transactions'