from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import render
from django.db.models import Sum, Case, When, F, Value, IntegerField, Count, Q
from django.db.models.functions import ExtractMonth
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.signals import user_logged_in
from bank.serializers import UserSerializer, RefreshTokenSerializer, TransactionSerializer, UserDetailSerializer
from rest_framework.views import APIView
from bank.models import Transaction
from django.core.paginator import Paginator
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.authentication import SessionAuthentication
from rest_framework.exceptions import PermissionDenied, AuthenticationFailed
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password , make_password
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
# Create your views here.

User = get_user_model()

class APIViewResponseMixin:
    STATUS_SUCCESS = 'SUCCESS'
    STATUS_FAILURE = 'FAILURE'

    @classmethod
    def success_response(cls, data, message='', status_code=status.HTTP_200_OK, response_class=Response):
        return response_class(dict(
            status=cls.STATUS_SUCCESS,
            data=data,
            message=message
        ), status=status_code)

    @classmethod
    def failure_response(
            cls,
            error_code,
            message,
            data={},
            status_code=status.HTTP_300_MULTIPLE_CHOICES,  # we would consider it a success if errors are known
            response_class=Response
    ):
        return response_class(dict(
            status=cls.STATUS_FAILURE,
            data=data,
            message=message,
            error_code=error_code
        ), status=status_code)

class BaseAPIView(APIView, APIViewResponseMixin):
    pass

class BaseModelViewSet(viewsets.ModelViewSet, APIViewResponseMixin):
    pass

class AuthenticationAPIView(BaseAPIView):
    authentication_classes = [JWTAuthentication, SessionAuthentication]
    permission_classes = [IsAuthenticated]

class AuthLoginView(TokenObtainPairView, BaseAPIView):

    def post(self, request):
        email = request.data.get('email')   
        first_name = request.data.get('first_name', None)
        last_name = request.data.get('last_name', None)
        user = User.objects.filter(email = email)
        
        try:
            if user:
                serializer = UserSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
            else:
                User.objects.create(email=email, balance='1000', first_name=first_name, last_name=last_name, initial_balance='1000')
                serializer = UserSerializer(data={'email':email})
                serializer.is_valid(raise_exception=True)

        except TokenError as e:
            raise InvalidToken(e.args[0])
        except PermissionDenied as ex:
            return self.failure_response(
                error_code='REVOKED',
                message=_('Your account is temporarily blocked due to too many failure login attempts.')
            )
        except AuthenticationFailed:
            return self.failure_response(
                error_code='INVALID_DATA', message=_(f'Invalid Credentials')
            )
        serializer.validated_data['already_exist'] = True if user else False
        # user_logged_in.send(sender=serializer.validated_data.user.__class__, request=request, user=serializer.validated_data.user)
        return self.success_response(data=serializer.validated_data, message=_('Authentication is successful.'))
    
class TokenVerifyView(BaseModelViewSet):

    def token_verify(self, request):
        request_data = request.data
        access_token_obj = AccessToken(request_data.get('token'))
        try:
            access_token_obj['user_id']
            return self.success_response(data={}, message=_("MESSAGE_TOKEN_VERIFIED"))
        except:       
            return self.failure_response(
                    error_code="ERROR_INVALID_TOKEN", message=_("MESSAGE_INVALID_TOKEN")
                )


class AuthTokenRefreshView(TokenRefreshView, BaseAPIView):
    serializer_class = RefreshTokenSerializer

    def post(self, request):
        try:
            response = super().post(request)
            response.data['expired_in_hours'] = settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'].total_seconds() / 3600
            return self.success_response(data=response.data, message=_('Token Refreshed successfully.'))
        except Exception as ex:
            return self.failure_response(
                error_code='INVALID_DATA', message=str(ex)
            )
class UserManager(AuthenticationAPIView, BaseModelViewSet):
    def update_user(self, request):
        request_data = request.data
        id =  request_data.get('id', None)
        user = User.objects.filter(id = id).first()  
        if request_data.get('first_name', None):
            user.first_name = request_data.get('first_name', None)
        if request_data.get('last_name', None):
            user.last_name = request_data.get('last_name', None)
        if request_data.get('email', None):
            user.email = request_data.get('email', None)
        if request_data.get('account_number', None):
            user.account_number = request_data.get('account_number', None)
        if request_data.get('balance', None):
            user.balance = request_data.get('balance', None)
            user.initial_balance = request_data.get('balance', None)
        user.save()
        data= UserDetailSerializer(user)

        return self.success_response(data={"user_details" : data.data}, message="MESSAGE_UPDATED_SUCCESSFULLY")
        
class TransactionView(BaseModelViewSet):

    def transaction(self, request):
        user = request.user
        amount =  request.data.get('amount', None)
        is_credit = request.data.get('is_credit', None) if request.data.get('is_credit', None)  else False
        type = request.data.get('type', None)
        transaction_type = request.data.get('transaction_type', None)
        alert = True if  user.balance // 2  <= amount else False
        if is_credit:
            User.objects.filter(id = user.id).first()
            user.balance += amount
            user.save()
            Transaction.objects.create(user=user, amount=amount, is_credit=is_credit, type=type, transaction_type=transaction_type)
            return self.success_response(data={"alert":alert, "transaction": "SUCCESS"}, message="MESSAGE_UPDATED_SUCCESSFULLY")    
        elif user.balance >= amount :
            user.balance -= amount
            user.save()
            Transaction.objects.create(user=user, amount=amount, is_credit=is_credit, type=type, transaction_type=transaction_type)
            return self.success_response(data={"alert":alert, "transaction": "SUCCESS", "balance":user.balance}, message="MESSAGE_UPDATED_SUCCESSFULLY")
        else: 
            pass
        

        return self.failure_response(data={"alert":True, "transaction": "FAILED"}, message="transaction FAILED: INSUFFICIENT BALANCE", error_code="INSUFFICIENT BALANCE")        
            
        

    def graph_data(self, request):
        user = request.user

        listing = Transaction.objects.filter(user=user).values('created_at').annotate( credit=Sum(
        Case(
            When(is_credit=True, then=F('amount')),
            default=Value(0),
            output_field=IntegerField()
        )
    ),
        debit=Sum(
            Case(
            When(is_credit=False, then=F('amount')),
            default=Value(0),
            output_field=IntegerField()
            )
            ))
        
        transactions_per_month = Transaction.objects.filter(user=user).annotate(
            monthName=ExtractMonth('created_at')
            ).values('monthName').annotate(
                value=Sum('amount'),
            )
        

        income_per_month =  Transaction.objects.filter(user=user).annotate(
            monthName=ExtractMonth('created_at')
            ).values('monthName').annotate(
                value=Sum('amount'),
             monthIncome=F('user__initial_balance'),
            )

        expense_per_month =  Transaction.objects.filter(user=user).annotate(
            monthName=ExtractMonth('created_at')
            ).values('monthName', 'transaction_type').annotate(
                value=Sum('amount'),
                monthIncome=Sum('user__balance'),
            )
        

        values =   Transaction.objects.filter(user=user).annotate(
            monthName=ExtractMonth('created_at')
            ).values('monthName', 'transaction_type').annotate(
                value=Sum('amount'),
            ).order_by('-monthName').first()
        
        bank_balance = User.objects.filter(id=request.user.id).values('initial_balance').first()
        values_left  = values.get('value', 0) if values else 0
        expense  = {'total_income': bank_balance.get('initial_balance', 0), "expense": values_left, 'left':bank_balance.get('initial_balance', 0)- values_left}
        summary_list = list(listing)
        total_credit = Transaction.objects.filter(user=user, is_credit=True).aggregate(total_credit=Sum('amount'))['total_credit'] or 0
        total_debit = Transaction.objects.filter(user=user, is_credit=False).aggregate(total_debit=Sum('amount'))['total_debit'] or 0
        total_amount = total_credit + total_debit
        credit_percentage = (total_credit / total_amount) * 100 if total_amount else 0
        debit_percentage = (total_debit / total_amount) * 100 if total_amount else 0
        # for data in listing:
        #     bar={}
        #     bar['date'] = data.created_at
        #     if data.is_credit:
        #         bar['credit'] = data.amount
        #     else:
        #         bar['debit'] = data.amount
        #     bar_data.append(bar)


        pie_chart = [{"credit":credit_percentage}, {"debit":debit_percentage}]
        return self.success_response(data={"bar":summary_list, "pie": pie_chart, 
                                           "transactions_per_month":transactions_per_month, "income_per_month":income_per_month
                                           , 'expense_per_month':expense_per_month, 'expense':expense})

            


    def listing(self, request):
        user = request.user
        filters={}
        page_number = request.data.get("page_number", 1)
        row_count = request.data.get("row_count", None)

        if request.data.get('type', None) and request.data.get('type', None)!='all':
            filters['type'] = request.data.get('type', None)

        listing = Transaction.objects.filter(user=user, **filters).order_by('-created_at')
        if row_count and page_number:
            paginator = Paginator(listing, row_count)
            listing = paginator.get_page(page_number)
        serializer = TransactionSerializer(listing, many=True)
        
        return self.success_response(data={"listing":serializer.data})
