from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth import get_user_model
from bank.models import Transaction

# Register your models here.
User = get_user_model()

@admin.register(User)
class UserAdmin(UserAdmin):
    model = User
    list_display = ('username', 'email', "balance", "account_number")
    fieldsets = (
        (None, {'fields': ('username', 'email', "balance", "account_number", "initial_balance", "is_staff","is_active")}),
    )
    
@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    model = User
    list_display = ('amount', 'is_credit', "user", "transaction_type", "type")
    fields = ('amount', 'is_credit', "user", "transaction_type", "type")
    