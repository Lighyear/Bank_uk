package com.example.bank_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
