import 'package:get/get.dart';

class BaseController extends GetxController {}
