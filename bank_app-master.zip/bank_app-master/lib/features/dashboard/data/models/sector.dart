import 'package:flutter/material.dart';

class Sector {
  final Color color;
  final double value;

  Sector({required this.color, required this.value});
}
