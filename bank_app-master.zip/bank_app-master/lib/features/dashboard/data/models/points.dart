class Points {
  double x;
  double y;

  Points({
    required this.x,
    required this.y,
  });
}
